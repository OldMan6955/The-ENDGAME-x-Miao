**Level: Beginner 😁**

- The basics!
- Demonstrates direct pin keys, tap dance, combos, basic hold-tap, and basic keycodes.
